package coreJava;

public class Methodsdemo2 {

	public void getuserData() {
		System.out.println("I am method from anotherclass ");
	}


}
