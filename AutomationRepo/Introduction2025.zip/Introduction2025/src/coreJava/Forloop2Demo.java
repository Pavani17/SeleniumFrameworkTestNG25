package coreJava;

public class Forloop2Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr2 = {17,06,1994,2007,2010};
		
		for(int i=0;i<arr2.length;i++)
		{
			System.out.println(arr2[i]);
		}
		
		
		String[] name = {"pavani","kakileti","Automation testing"};
		
		for(int j=0;j< name.length;j++)
		{
			System.out.println(name[j]);
		}
	}

}
