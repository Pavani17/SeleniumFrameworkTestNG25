package Frameworks25.SeleniumFrameworkDesign25;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.testng.Assert;

/**
 * Unit test for simple App.
 */
public class AppTest {

    /**
     * Rigorous Test :-)
     */
    @org.testng.annotations.Test
    public void shouldAnswerWithTrue() {
        Assert.assertTrue(true);
    }
}
