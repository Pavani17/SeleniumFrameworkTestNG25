package coreJava2;

public class PackageDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PackageDemo1 pd = new PackageDemo1() ;
		pd.getPack();
	}

}
