package coreJava2;

public class DefaultDemo {

	int i=10;
	
	public int j=20;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	
	 void getdefault()
	{
		System.out.println("Has default modifier");
	}
	 
	 
	public void getPublic()
		{
			System.out.println("Has public modifier");
		}


}
