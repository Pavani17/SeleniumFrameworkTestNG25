package coreJava2;

public class ProtectedParent{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ProtectedDemo pd = new ProtectedDemo();
		pd.getProtectedData();
	}

}
