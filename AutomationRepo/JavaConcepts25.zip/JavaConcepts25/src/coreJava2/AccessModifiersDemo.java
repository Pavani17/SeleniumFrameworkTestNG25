package coreJava2;


public class AccessModifiersDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefaultDemo dd=new DefaultDemo();
		dd.getdefault();
		dd.getPublic();
		dd.i;
		dd.j;
		
		PrivateaccessmodifierDemo pd=new PrivateaccessmodifierDemo();
		
			
	}

}
