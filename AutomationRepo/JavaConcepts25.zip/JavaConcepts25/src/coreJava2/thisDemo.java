package coreJava2;

public class thisDemo {
	
	int a=20;
	
	public void getData()
	{
		int a=38;
		System.out.println(a);
		System.out.println(this.a);
		int b= this.a+a;
		System.out.println(b);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		thisDemo td=new thisDemo();
		td.getData();
		
	}

}
