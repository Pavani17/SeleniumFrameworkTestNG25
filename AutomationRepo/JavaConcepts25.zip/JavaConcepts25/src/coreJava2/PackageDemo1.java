package coreJava2;

public class PackageDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public void getPack()
	{
		System.out.println("class from coreJava2 package");
	}

}
