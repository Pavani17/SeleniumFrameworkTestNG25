package coreJava2;

public class ExceptionsDemo {

		
public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 int a = 7;
			int b = 0;
			

		 try 
		 {
			// int c=a/b;
			
			// System.out.println(c);
			 
			 int arr[] = new int[4];
			 
			 System.out.println(arr[5]);
		 }
		 
		 catch(ArithmeticException et)
		 {
			 System.out.println(et);
		 }
		 
		 catch(IndexOutOfBoundsException eo)
		 {
			 System.out.println(eo);
		 }
		 
		 catch(Exception e)
		 {
			System.out.println("catched exception"); 
		 }
		 
		 finally
		 {
			System.out.println("delete cookies"); 
		 }
		
	}

}
