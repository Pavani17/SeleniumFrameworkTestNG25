package coreJava2;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Datedemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date d = new Date();
	
		
		SimpleDateFormat sdf=new SimpleDateFormat("M/d/yyyy");
		

		SimpleDateFormat sd=new SimpleDateFormat("M/d/yyyy HH:m:s");
		System.out.println(sd.format(d));
		System.out.println(sdf.format(d));
		System.out.println(d.toString());
	}

}
