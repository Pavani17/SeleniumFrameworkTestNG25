package coreJava2;

final class FinalParent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
