package coreJava2;

public class ProtectedDemo{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	protected void getProtectedData()
	{
		System.out.println("protected data");
	}

}
