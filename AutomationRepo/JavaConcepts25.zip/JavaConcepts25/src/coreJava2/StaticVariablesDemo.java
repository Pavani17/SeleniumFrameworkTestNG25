package coreJava2;

public class StaticVariablesDemo {

	String name;
	String address;
	static String city ="hyderabad";
	static int i=0;

	public StaticVariablesDemo(String name, String address) {

		this.name = name;
		this.address = address;
		i++;
		System.out.println(i);
		
	}
	
	public void getAddress()
	{
		System.out.println(address +" "+ city);
	}
	
	public static  void getstaticData()
	{
		System.out.println(city);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticVariablesDemo sd = new StaticVariablesDemo("pavani", "amalapuram");
		
		StaticVariablesDemo sd1 = new StaticVariablesDemo("sri", "amp");
		
		StaticVariablesDemo sd2 = new StaticVariablesDemo("satya", "plk");
		sd.getAddress();
		sd1.getAddress();
		sd2.getAddress();
		StaticVariablesDemo.getstaticData();
	}

}
