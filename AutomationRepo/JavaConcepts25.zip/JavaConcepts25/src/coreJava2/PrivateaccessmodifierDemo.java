package coreJava2;

public class PrivateaccessmodifierDemo {

	private k=70;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	private void getPrivateData()
	
	{
		System.out.println("private modifier");
	}

}
