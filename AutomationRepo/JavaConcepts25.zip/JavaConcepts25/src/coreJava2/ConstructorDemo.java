package coreJava2;

public class ConstructorDemo {

	public ConstructorDemo() {
		System.out.println("I am from consturctor");
	}

	public ConstructorDemo(int a, int b) {
		System.out.println("I am parametersed consturctor");
	}
	
	public ConstructorDemo(String name) {
		System.out.println(name);
	}


	public void getData() {
		System.out.println("from method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConstructorDemo cd = new ConstructorDemo();

		ConstructorDemo cd1 = new ConstructorDemo(2, 6);
		
		ConstructorDemo cd2 = new ConstructorDemo("pavani");
	}

}
