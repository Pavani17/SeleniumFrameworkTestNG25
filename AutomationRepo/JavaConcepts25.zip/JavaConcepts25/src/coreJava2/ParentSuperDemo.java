package coreJava2;

public class ParentSuperDemo {
	
	public ParentSuperDemo()
	{
		System.out.println("parent constructor");
	}

	
	String name ="Pavani";
	
	public void getData() {
		System.out.println("I am from parent class");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
