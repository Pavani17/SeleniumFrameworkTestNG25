package coreJava2;

public class FinalDemo extends FinalParent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int i = 5;
		
		i=10;
		
		
			}
	
	
	final void getdata()
	{
		
	}
	



}
