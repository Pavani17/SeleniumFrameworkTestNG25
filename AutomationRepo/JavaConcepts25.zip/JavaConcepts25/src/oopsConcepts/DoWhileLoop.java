package oopsConcepts;

public class DoWhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 20;

		do {
			System.out.println(i);
			i++;
		} while (i < 30);
	
	
	int k=20;
	
	do
	{
	System.out.println(k);	
	k++;
	} while(k>30);

}
	
}
