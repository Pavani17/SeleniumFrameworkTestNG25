package oopsConcepts;

public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = new int[5];
		a[0] = 12;
		a[1] = 25;
		a[2] = 50;
		a[3] = 100;
		a[4] = 200;
		
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		int b[] = {67,73,90};
		
		for(int i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
	}

}
