package oopsConcepts;

public class FunctionOverridingChildDemo  extends FunctionOverridingParentDemo  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FunctionOverridingChildDemo cd=new FunctionOverridingChildDemo();
		cd.getOverriding();
	}
	
	public void getOverriding()
	{
		System.out.println("child overriding");
	}
	

}
