package oopsConcepts;

public interface Interface2 {
	
	public void favColour();

}
