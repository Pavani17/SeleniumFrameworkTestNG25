package oopsConcepts;

import demoOOPS.InterfaceDemo;

public class InterfaceClassDemo implements InterfaceDemo, Interface2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceDemo	 indemo =new InterfaceClassDemo();
		indemo.greenGo();
		indemo.redStop();
		indemo.flashYellow();
		InterfaceClassDemo cd	=new InterfaceClassDemo();
		cd.getClassData();
		
		Interface2 i2= new InterfaceClassDemo();
		i2.favColour();
	}
	
	public void getClassData()
	{
		System.out.println("from class method and not from interface method");
	}

	@Override
	public  void greenGo() {
		// TODO Auto-generated method stub
		System.out.println("green");
	}

	@Override
	public void redStop() {
		// TODO Auto-generated method stub
		System.out.println("red");
	}

	@Override
	public void flashYellow() {
		// TODO Auto-generated method stub
		System.out.println("yellow");
	}

	@Override
	public void favColour() {
		// TODO Auto-generated method stub
		System.out.println("Blue colour from interface2");
	}

}
