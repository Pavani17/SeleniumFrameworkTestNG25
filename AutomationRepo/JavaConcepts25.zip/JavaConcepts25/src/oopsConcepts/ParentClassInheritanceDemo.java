package oopsConcepts;

public class ParentClassInheritanceDemo {

	 String colour = "Black";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
	
	
	public void getParentManual()
	{
		System.out.println("6 yrs in manual from parent");
	}
	
	public void getParentAutomation()
	{
		System.out.println("Learning automation from parent");
	}

}
