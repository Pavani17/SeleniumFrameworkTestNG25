package oopsConcepts;

public class ChildClassInheritanceDemo extends ParentClassInheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ChildClassInheritanceDemo cd = new ChildClassInheritanceDemo();
		cd.getParentAutomation();
		cd.getParentManual();
		cd.childAutomation();
		cd.childManual();
		cd.getColour();
	}

	public void childManual() {
		System.out.println("Manual Tester from child");
	}

	public void childAutomation() {
		System.out.println("Selenium from child");
	}

	public void getColour() {

		System.out.println(colour + "variable declared in parent class");
	}

}
