package oopsConcepts;

public class MultiDimensionArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[] [] =new int[2][3];
		
		a[0][0] =10;
		a[0][1]=4;
		a[0][2]=9;
		a[1][0]=70;
		a[1][1]=86;
		a[1][2]=45;
		
		System.out.println(a[1][0]);
		
		int b[][]= {{9,6,5},{3,8,20}};
		
		System.out.println(b[1][2]);
		
		for(int i=0;i<2;i++) {
			for(int j=0;j<3;j++)
			{
				System.out.println(b[i][j]);
			}
		}
	}

}
