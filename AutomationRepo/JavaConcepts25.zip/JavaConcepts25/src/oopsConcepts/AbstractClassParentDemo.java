package oopsConcepts;

public abstract class AbstractClassParentDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	
	public void getManual()
	{
		System.out.println("Functional tester");
	}
	
	public void getSelenium()
	{
		System.out.println("Selenium automation");
	}
	
	public abstract void getAPIJava();

}
