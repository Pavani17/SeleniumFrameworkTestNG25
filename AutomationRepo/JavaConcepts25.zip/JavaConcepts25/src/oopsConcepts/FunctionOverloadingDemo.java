package oopsConcepts;

public class FunctionOverloadingDemo {

	int b = 50;
	String name = "Pavani";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FunctionOverloadingDemo fd =new FunctionOverloadingDemo();
		fd.getData(25);
		fd.getData("pavani");
		fd.getData(30, 45);
				
	}

	public void getData(int a) {
		System.out.println(a);
	}

	public void getData(int a, int b) {
		System.out.println(a + "and " + b);
	}

	public void getData(String a) {
		System.out.println(a);
	}

}
