package oopsConcepts;

public class InheritanceDemoB  extends InheritanceDemoA{

	int i=30;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InheritanceDemoB  indemoB =new InheritanceDemoB();
		System.out.println(indemoB.i);
		
		
		InheritanceDemoA indemoA =new InheritanceDemoA();
		System.out.println(indemoA.i);
	}

}
