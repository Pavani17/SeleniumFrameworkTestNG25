package oopsConcepts;

public class ChildAbstractDemo extends  AbstractClassParentDemo{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChildAbstractDemo cd =new ChildAbstractDemo();
		cd.getManual();
		cd.getSelenium();
		cd.getAPIJava();
	}

	@Override
	public void getAPIJava() {
		// TODO Auto-generated method stub
		System.out.println("upskill API Testing");
	}

}
