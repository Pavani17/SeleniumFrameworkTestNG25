package oopsConcepts;

public class FunctionOverridingParentDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public void getOverriding()
	{
		System.out.println("parent overriding");
	}
	

}
