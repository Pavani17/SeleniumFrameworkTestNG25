package oopsConcepts;

public class WhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i = 0;

		while (i <= 10) {

			System.out.println(i);
			i++;
		}

		int j = 10;

		while (j > 0) {
			System.out.println(j);
			j--;
		}
	}

}
