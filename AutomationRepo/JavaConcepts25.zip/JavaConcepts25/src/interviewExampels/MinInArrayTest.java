package interviewExampels;

public class MinInArrayTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int b[][] = { { 9, 16, 50 }, { 3, 28, 20 }, { 45, 90, 88 } };

		for (int i = 0; i < 3; i++) {

			for (int j = 0; j < 3; j++) {
				int min = b[0][0];

				if (b[i][j] < min) {
					System.out.println(b[i][j]);
				}
			}
		}
	}

}
