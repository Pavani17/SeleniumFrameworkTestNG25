package interviewExampels;

public class MaxInArrayTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int b[][] = { { 9, 16, 50 }, { 3, 28, 20 }, { 45, 90, 88 } };

		int min = b[0][0];
		int mincoloumn = 0;

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (b[i][j] < min)// 2
				{
					min = b[i][j];
					mincoloumn = j;
				}
			}
		}

		int max = b[0][mincoloumn];
		int k = 0;
		while (k < 3) {
			if (b[k][mincoloumn] > max) {
				max = b[k][mincoloumn];
			}
			k++;
		}

		System.out.println(max);
	}

}
