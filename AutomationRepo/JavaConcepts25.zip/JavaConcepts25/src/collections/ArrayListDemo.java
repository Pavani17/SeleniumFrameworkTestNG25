package collections;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> al = new ArrayList<String>();
		al.add("pavani");
		al.add("satya");
		al.add("kakileti");
		al.add("testing");
		System.out.println(al);
		al.add(0,"sri");
		System.out.println(al);
		al.remove(0);
		System.out.println(al);
		al.remove("kakileti");
		System.out.println(al);
		
		System.out.println(al.get(1));
		
		System.out.println(al.contains("testing"));
		
		System.out.println(al.size());
		al.removeAll(al);
			System.out.println(al);
			System.out.println(al.isEmpty());
		
	}

}
