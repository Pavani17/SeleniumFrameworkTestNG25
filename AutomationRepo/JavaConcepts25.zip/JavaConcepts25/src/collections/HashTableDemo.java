package collections;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashTableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hashtable<Integer, String> mp = new Hashtable<Integer, String>();
		mp.put(12, "Hello");
		mp.put(67, "Pavani");
		mp.put(73, "Take care");
		mp.put(6, "Bye Bye");

		System.out.println(mp.get(73));

		mp.remove(6);
		System.out.println(mp.get(6));

		Set sn = mp.entrySet();
		/*Iterator it = sn.iterator();
		while (it.hasNext()) {
			// System.out.println(it.next());

			Map.Entry me = (Map.Entry) it.next();
			System.out.println(me.getKey());
			System.out.println(me.getValue());*/

		//}
	}

}
