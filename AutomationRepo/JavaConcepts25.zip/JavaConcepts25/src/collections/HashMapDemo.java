package collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, String> mp = new HashMap<Integer, String>();
		mp.put(12, "Hello");
		mp.put(67, "Pavani");
		mp.put(73, "Take care");
		mp.put(6, "Bye Bye");
		mp.put(1,"Hello");
		mp.put(67,"satya");
		System.out.println(mp);

		System.out.println(mp.get(73));

		mp.remove(6);
		System.out.println(mp.get(6));

		Set sn = mp.entrySet();
		Iterator it=sn.iterator();
		while(it.hasNext())
		{
			//System.out.println(it.next());
			
			Map.Entry me=(Map.Entry)it.next();
		System.out.println(me.getKey());
		System.out.println(me.getValue());
			
		}
	}

}
