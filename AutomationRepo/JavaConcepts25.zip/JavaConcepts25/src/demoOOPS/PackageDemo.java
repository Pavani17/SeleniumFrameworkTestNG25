package demoOOPS;

import coreJava2.PackageDemo1;

public class PackageDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PackageDemo1 pd = new PackageDemo1() ;
		pd.getPack();
	}

}
