package demoOOPS;

import coreJava2.DefaultDemo;
import coreJava2.ProtectedDemo;

public class AccessModifiersDemo extends ProtectedDemo{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefaultDemo dd=new DefaultDemo();
		dd.getdefault();
		dd.getPublic();
		
		dd.j;
		
		AccessModifiersDemo ad=new AccessModifiersDemo();
		ad.getProtectedData();
	}

}
