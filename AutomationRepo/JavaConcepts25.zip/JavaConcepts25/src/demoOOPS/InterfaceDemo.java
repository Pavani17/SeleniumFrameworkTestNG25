package demoOOPS;

public interface InterfaceDemo {
	
	public void greenGo();
	
	public void redStop();
	
	public void flashYellow();

}
