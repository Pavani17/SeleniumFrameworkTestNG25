import java.util.HashMap;
import java.util.Map;

public class IncrementValueinMap {
	/*
	 * You initialize a HashMap with "apple" mapped to 2. You use
	 * getOrDefault("apple", 0), which retrieves the current value (2), or 0 if the
	 * key is absent. You add 1 to the retrieved value and update the map with
	 * map.put("apple", 3). Finally, you print the map, which results in {apple=3}.
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		        Map<String, Integer> map = new HashMap<>();
		        map.put("apple", 2);

		        // Increment value
		        map.put("apple", map.getOrDefault("apple", 0) + 1);

		        System.out.println(map); // Output: {apple=3}
		    
	}

}
