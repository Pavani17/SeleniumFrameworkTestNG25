
public class ReverseFirstName {

	/*
	 * Splitting the Full Name: We use split(" ", 2), which means: The first part
	 * (words[0]) will be the first name ("Pavani"). The second part (words[1]) will
	 * be the remaining name ("Satyavathi"). 2 in split(" ", 2) ensures that the
	 * last name stays together, even if it has multiple words.
	 * 
	 * 
	 * Checking if the Last Name Exists: If there's only one word (e.g., "Pavani"
	 * with no last name), we reverse it and print it. If there’s both a first and
	 * last name ("Pavani Satyavathi"), we reverse only the first name and keep the
	 * last name unchanged.
	 * 
	 * Reversing the First Name (Except the First Letter): word.charAt(0): Keeps the
	 * first letter as it is (P). word.substring(1): Extracts the rest of the word
	 * ("avani"). new StringBuilder(...).reverse().toString(): Reverses "avani" →
	 * "ianav". Combines both: P + ianav → "Pianav".
	 */

	// Example full name
	public static void main(String[] args) {
		String fullName = "My name is Pavani Satyavathi";
		String result = reverseFirstName(fullName);
		System.out.println(result);

	}

	public static String reverseFirstName(String fullName) {

		String[] words = fullName.split(" "); // Split into string into parts using space

		// identify firstname assuming it's 4 th word of in the sentence

		String firstName = words[3];

		// reverse firstname

		String reverseFirstname = new StringBuilder(firstName).reverse().toString();

		// replace original firstname with reversed one
		words[3] = reverseFirstname;

		// join words back into single string

		return String.join(" ", words);
	}
}
