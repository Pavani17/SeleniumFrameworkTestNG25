
public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String str = "I love my India";   // Step 1: Define the input string
        String[] words = str.split(" ");  // Step 2: Split the string into words
        StringBuilder result = new StringBuilder(); // Step 3: Create a StringBuilder for output

        // Step 4: Iterate through the words in reverse order
        for (int i = words.length - 1; i >= 0; i--) {
            result.append(words[i]).append(" "); // Step 5: Append words in reverse order
        }

        System.out.println(result.toString().trim()); // Step 6: Print the result
	
	}

}
