
public class ReverseStringandPrint2ndAlphabet {

	
	 public static void main(String[] args) {
	        String input = "Automation"; // Example input
	        String reversed = new StringBuilder(input).reverse().toString();

	        System.out.println("Reversed String: " + reversed);

	        if (reversed.length() > 1) {
	            System.out.println("Second alphabet in reversed string: " + reversed.charAt(1));
	        } else {
	            System.out.println("The string is too short to have a second character.");
	        }
	    }
}
