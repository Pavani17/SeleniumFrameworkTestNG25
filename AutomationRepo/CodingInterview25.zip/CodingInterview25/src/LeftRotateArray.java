import java.util.Arrays;

public class LeftRotateArray {
	
	
	
	/*
	 * Explanation of the Code: Define the array We have an array {1, 2, 3, 4, 5, 6,
	 * 7} and we want to rotate it left by 2 positions.
	 * 
	 * Store the first d elements
	 * 
	 * We create a temporary array temp to store the first d elements {1, 2}. Shift
	 * the remaining elements
	 * 
	 * We move the remaining elements {3, 4, 5, 6, 7} forward to fill the first d
	 * positions. Place the stored elements at the end
	 * 
	 * We copy {1, 2} from temp to the end of the array. Example Walkthrough: Before
	 * Rotation: [1, 2, 3, 4, 5, 6, 7]
	 * 
	 * Store {1, 2} in temp Shift remaining elements: → [3, 4, 5, 6, 7, 6, 7] Copy
	 * {1, 2} to the end: → [3, 4, 5, 6, 7, 1, 2]
	 */

	 public static void main(String[] args) {
        int[] arr = {11, 22, 3, 4, 5, 6, 7};
        int positions = 2;
        //rotate array to left by 2 positions
        rotateLeft(arr, positions);
        System.out.println("Array after left rotation: " + Arrays.toString(arr));
    }

    public static void rotateLeft(int[] arr, int positions) {
        int n = arr.length;
        
        
        int[] temp = new int[positions]; // Store first positions  elements in temporary array
        for (int i = 0; i < positions; i++) {
            temp[i] = arr[i];
        }
        
        for (int i = positions; i < n ; i++) { // Shift remaining elements to left
            arr[i-positions] = arr[i];
        }
        
        for (int i = 0; i < positions; i++) { // Copy temp elements to end
            arr[n - positions + i] = temp[i];
        }
        
    }

}
