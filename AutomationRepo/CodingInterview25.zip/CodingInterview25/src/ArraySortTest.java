import java.util.Arrays;

public class ArraySortTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int [] arr= {67,473,6,4,20,45};
		
		Arrays.sort(arr);
		
		System.out.println(Arrays.toString(arr));
	}

}
