import java.util.HashSet;

public class FindMissingNumberHashSet {
	
	
	/*
	 * How It Works: Store Given Numbers in a HashSet
	 * 
	 * The HashSet<Integer> is used to store the given numbers. This allows for O(1)
	 * lookup time when checking if a number exists. Iterate from 1 to n (10 in this
	 * case)
	 * 
	 * Check if each number is present in the HashSet. If a number is not found,
	 * print it as missing.
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] numbers = {1, 2, 3, 5, 7, 8, 10}; // Example missing 4, 6, 9
	        int n = 10; // Change to 100 for 1 to 100

	        HashSet<Integer> numSet = new HashSet<>();
	        for (int num : numbers) {
	            numSet.add(num);
	        }

	        System.out.print("Missing Numbers: ");
	        for (int i = 1; i <= n; i++) {
	            if (!numSet.contains(i)) {
	                System.out.print(i + " ");
	            }
	  
	        }
	       
	}
	

}
