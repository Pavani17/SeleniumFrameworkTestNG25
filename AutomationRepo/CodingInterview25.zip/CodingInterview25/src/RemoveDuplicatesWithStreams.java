import java.util.stream.Collectors;

public class RemoveDuplicatesWithStreams {
	public static String removeDuplicates(String str) {
        return str.chars() // Convert string to IntStream of character ASCII values
                  .distinct() // Remove duplicates
                  .mapToObj(c -> String.valueOf((char) c)) // Convert int back to character
                  .collect(Collectors.joining()); // Join characters to form a new string
    }

    public static void main(String[] args) {
        String input = "programming";
        System.out.println(removeDuplicates(input));  // Output: "progamin"
    }
}
