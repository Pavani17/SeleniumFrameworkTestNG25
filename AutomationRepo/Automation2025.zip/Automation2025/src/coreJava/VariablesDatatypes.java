package coreJava;

public class VariablesDatatypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 2025;
		String name = "pavani";

		char ch = 'p';

		double dec = 17.94;

		boolean mySelf = true;

		System.out.println(num);

		System.out.println(name);
		System.out.println(ch);
		System.out.println(dec);
		System.out.println(mySelf);

		System.out.println(name + "is learning selenium in" + " " + num + " " + "which is" + " " + mySelf);
	}

}
