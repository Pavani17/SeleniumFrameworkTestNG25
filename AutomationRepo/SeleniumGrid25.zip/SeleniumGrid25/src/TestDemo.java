import java.net.URI;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class TestDemo {

	@Test
	public void HomePageCheck() {
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setBrowserName("chrome");
		// caps.setPlatform(Platform.);
//		caps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
//		caps.setCapability(CapabilityType.BROWSER_NAME, "chrome");

		WebDriver driver = new RemoteWebDriver(new URI("http://192.168.1.139:4444").ToURL, caps);
		driver.get("http://google.com");
		System.out.println(driver.getTitle());
		driver.findElement(By.name("q")).sendKeys("rahul shetty");
		driver.close();

	}

}
