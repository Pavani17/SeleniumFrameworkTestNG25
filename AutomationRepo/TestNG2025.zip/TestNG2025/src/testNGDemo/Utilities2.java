package testNGDemo;

public class Utilities2 {
	
	int a;
	public Utilities2(int a) {
		
		this.a=a;
	}
	
	public int multiplyTwo()
	{
		a=a*2;
		return a;
	}
	
	public int multiplyThree()
	{
		a=a*3;
		return a;
	}

}
